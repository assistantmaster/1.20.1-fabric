 _   _        ______                      _    _       
| \ | |       | ___ \                    | |  (_)      
|  \| | ___   | |_/ /   _ _ __ ___  _ __ | | ___ _ __  
| . ` |/ _ \  |  __/ | | | '_ ` _ \| '_ \| |/ / | '_ \ 
| |\  | (_) | | |  | |_| | | | | | | |_) |   <| | | | |
\_| \_/\___/  \_|   \__,_|_| |_| |_| .__/|_|\_\_|_| |_|
                                   | |                 
                                   |_|                 
______ _            _                                  
| ___ \ |          | |                                 
| |_/ / |_   _ _ __| |                                 
| ___ \ | | | | '__| |                                 
| |_/ / | |_| | |  |_|                                 
\____/|_|\__,_|_|  (_)                                 
                                                       
                                                       


===============================================================================

TABLE OF CONTENTS 

1. ABOUT
2. CONTACT
3. INSTALL INSTRUCTIONS
4. TERMS OF USE
5. CHANGE LOG

============================================

1.  ABOUT

	�This texture pack does one thing.  It removes the pumpkin blur.
	�Current and past versions may be found at www.ordinarywonders.net


=============================================

2. CONTACT

eternitymine@ordinarywonders.net 

or visit www.ordinarywonders.net for FAQ and other information.

==============================================

3. INSTALL INSTRUCTIONSONS:

	1.	Run Minecraft in the version you wish to play and that is associated with the pack you are wanting to use.
	2.	Hit the "Play" button to launch the game.
	3.	Click on the "Options" button.
	4.	Click on the "Resource Packs" button.
	5.	Click on the "Open Resource Packs Folder" button.
	6.	Copy the zipped version of the pack you wish to install.
	7.	Paste it into the Resource packs Folder.
	8.	Close the window.
	9.	Now choose your pack by clicking the arrow displayed to add it to the "selected Resource Packs" list.
	10.	The pack that is listed on the top of the list will be the dominant pack and the game will choose to use that one first. If there are no graphics for a particular block/mob available in the top pack, the game will look for textures in the second pack listed, then third and so on. So it is possible to play the game with more than one resource pack selected. The default pack is always there and can't be removed from the list.

For more detailed and alternate instructions visit the FAQ section on the Ordinary Wonders website. https://www.ordinarywonders.net/faq

  
==============================================

4. TERMS OF USE & LICENSES & COPYRIGHT

-Do not hotlink
-Do not upload and redistribute
-Do not post links behind Adfly and similar advertising.
-You must link any downloads to the corresponding download page on ordinarywonders.net
-The copyright & terms applies to all OrdinaryWonders versions and content.

-See https://www.ordinarywonders.net/copyright-and-permissions for the complete Copyright and Permissions of Use.

-See https://www.ordinarywonders.net/terms-and-conditions for complete Terms & Conditions for all OrdinaryWonders services.

These Terms and Conditions may be updated from time to time. The updated version will be posted on https://www.ordinarywonders.net and indicated by an updated �Revised� date. We encourage you to review this notice frequently to be informed of any Terms or Conditions that have been changed or updated before using or modifying any Ordinary Wonders downloads.

Copyright � OrdinaryWonders.net, EternityMine 2014-2023 All Rights Reserved


===============================================================================

CHANGE LOG:

2023-01-04
No Pumpkin Blur 1.19.3b
     �updated the readme file
     �updated the pack png
     �updated the pack to work in 1.19.3

2022-02-22
No Pumpkin Blur 1.19a
Caves & Cliffs part 2
     �updated the readme file
     �optimized the pumpkin blur and added the correspondng .json file
     �updated the pack to work in 1.19+

2022-02-22
No Pumpkin Blur 1.18
Caves & Cliffs part 2
     �updated the pack to work in 1.18+

2021-09-11
No Pumpkin Blur 1.17a
Caves & Cliffs part 1
     �Removed the pumpkin blur so you have clear vision when wearing pumpkin head.